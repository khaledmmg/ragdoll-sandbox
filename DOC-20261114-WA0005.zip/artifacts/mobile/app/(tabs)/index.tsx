import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  PanResponder,
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, {
  Circle,
  Defs,
  G,
  Line,
  LinearGradient as SvgGradient,
  Path,
  Rect,
  Stop,
  Text as SvgText,
} from 'react-native-svg';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import {
  BUMPERS,
  FLOOR_Y,
  JOINTS,
  PLATFORMS,
  WORLD_HEIGHT,
  WORLD_WIDTH,
  createPhysicsState,
  grabNearestPoint,
  launchRagdoll,
  moveGrabbedPoint,
  releaseGrabbedPoint,
  stepPhysics,
  type ModeId,
  type PhysicsState,
} from '@/game/physics';

type Screen = 'home' | 'game' | 'results' | 'locker';
type SkinId = 'mint' | 'citrus' | 'sky' | 'rose';

interface SaveData {
  coins: number;
  bestScores: Record<ModeId, number>;
  unlockedSkins: SkinId[];
  selectedSkin: SkinId;
}

interface ModeInfo {
  id: ModeId;
  title: string;
  shortTitle: string;
  subtitle: string;
  detail: string;
  icon: React.ComponentProps<typeof Feather>['name'];
}

interface SkinInfo {
  id: SkinId;
  name: string;
  colorToken: keyof ReturnType<typeof useColors>;
  cost: number;
}

const SAVE_KEY = 'bounce-lab-save-v1';
const DEFAULT_SAVE: SaveData = {
  coins: 0,
  bestScores: { bounce: 0, fan: 0, bumper: 0 },
  unlockedSkins: ['mint'],
  selectedSkin: 'mint',
};

const MODES: ModeInfo[] = [
  {
    id: 'bounce',
    title: 'BOUNCE BAY',
    shortTitle: 'Bounce',
    subtitle: 'Let the pads do the work.',
    detail: 'Stack clean landings for a bigger combo.',
    icon: 'activity',
  },
  {
    id: 'fan',
    title: 'WIND TUNNEL',
    shortTitle: 'Wind',
    subtitle: 'Catch the rising air.',
    detail: 'Grab, swing, and ride the gust across the room.',
    icon: 'wind',
  },
  {
    id: 'bumper',
    title: 'BUMP COURSE',
    shortTitle: 'Bumpers',
    subtitle: 'Find a new line through.',
    detail: 'Every safe collision adds to your score.',
    icon: 'target',
  },
];

const SKINS: SkinInfo[] = [
  { id: 'mint', name: 'Mint Circuit', colorToken: 'primary', cost: 0 },
  { id: 'citrus', name: 'Citrus Pop', colorToken: 'skinCitrus', cost: 45 },
  { id: 'sky', name: 'Sky Current', colorToken: 'skinSky', cost: 80 },
  { id: 'rose', name: 'Rose Rocket', colorToken: 'skinRose', cost: 125 },
];

function formatScore(score: number): string {
  return Math.max(0, Math.floor(score)).toLocaleString();
}

function getSkinColor(skin: SkinId, colors: ReturnType<typeof useColors>): string {
  const colorToken = SKINS.find((item) => item.id === skin)?.colorToken ?? 'primary';
  return colors[colorToken] as string;
}

function IconButton({
  icon,
  label,
  onPress,
  testID,
  color,
}: {
  icon: React.ComponentProps<typeof Feather>['name'];
  label: string;
  onPress: () => void;
  testID: string;
  color: string;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      testID={testID}
      onPress={onPress}
      style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}
    >
      <Feather name={icon} size={19} color={color} />
    </Pressable>
  );
}

function PrimaryButton({
  title,
  icon,
  onPress,
  testID,
  colors,
}: {
  title: string;
  icon: React.ComponentProps<typeof Feather>['name'];
  onPress: () => void;
  testID: string;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      testID={testID}
      onPress={onPress}
      style={({ pressed }) => [
        styles.primaryButton,
        { backgroundColor: colors.primary },
        pressed && styles.pressed,
      ]}
    >
      <Feather name={icon} size={18} color={colors.primaryForeground} />
      <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>{title}</Text>
    </Pressable>
  );
}

function Ragdoll({
  state,
  color,
  outline,
}: {
  state: PhysicsState;
  color: string;
  outline: string;
}) {
  const points = state.points;
  return (
    <G>
      {JOINTS.map((joint, index) => {
        const a = points[joint.a];
        const b = points[joint.b];
        return (
          <G key={`limb-${index}`}>
            <Line
              x1={a.x}
              y1={a.y}
              x2={b.x}
              y2={b.y}
              stroke={outline}
              strokeWidth={joint.width + 7}
              strokeLinecap="round"
            />
            <Line
              x1={a.x}
              y1={a.y}
              x2={b.x}
              y2={b.y}
              stroke={color}
              strokeWidth={joint.width}
              strokeLinecap="round"
            />
          </G>
        );
      })}
      {points.slice(1).map((point, index) => (
        <Circle
          key={`joint-${index}`}
          cx={point.x}
          cy={point.y}
          r={index > 7 ? 8 : 7}
          fill={color}
          stroke={outline}
          strokeWidth={4}
        />
      ))}
      <Circle
        cx={points[0].x}
        cy={points[0].y}
        r={points[0].radius}
        fill={color}
        stroke={outline}
        strokeWidth={5}
      />
      <Circle cx={points[0].x - 6} cy={points[0].y - 2} r={2.4} fill={outline} />
      <Circle cx={points[0].x + 6} cy={points[0].y - 2} r={2.4} fill={outline} />
      <Path
        d={`M ${points[0].x - 5} ${points[0].y + 7} Q ${points[0].x} ${points[0].y + 11} ${points[0].x + 5} ${points[0].y + 7}`}
        fill="none"
        stroke={outline}
        strokeWidth={2}
        strokeLinecap="round"
      />
    </G>
  );
}

function ModeCard({
  mode,
  selected,
  best,
  onPress,
  colors,
}: {
  mode: ModeInfo;
  selected: boolean;
  best: number;
  onPress: () => void;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      testID={`mode-${mode.id}`}
      onPress={onPress}
      style={({ pressed }) => [
        styles.modeCard,
        {
          backgroundColor: selected ? colors.secondary : colors.card,
          borderColor: selected ? colors.primary : colors.border,
        },
        pressed && styles.pressed,
      ]}
    >
      <View style={[styles.modeIcon, { backgroundColor: selected ? colors.primary : colors.secondary }]}>
        <Feather
          name={mode.icon}
          size={18}
          color={selected ? colors.primaryForeground : colors.accent}
        />
      </View>
      <View style={styles.modeText}>
        <Text style={[styles.modeTitle, { color: colors.foreground }]}>{mode.title}</Text>
        <Text style={[styles.modeSub, { color: colors.mutedForeground }]}>{mode.subtitle}</Text>
      </View>
      <Text style={[styles.modeBest, { color: colors.primary }]}>
        {best > 0 ? `BEST ${formatScore(best)}` : 'NEW'}
      </Text>
    </Pressable>
  );
}

function ArenaCanvas({
  state,
  mode,
  skinColor,
  colors,
  onLayout,
  responder,
}: {
  state: PhysicsState;
  mode: ModeId;
  skinColor: string;
  colors: ReturnType<typeof useColors>;
  onLayout: (width: number, height: number) => void;
  responder: ReturnType<typeof PanResponder.create>['panHandlers'];
}) {
  const modeTitle = MODES.find((item) => item.id === mode)?.title ?? MODES[0].title;
  return (
    <View
      {...responder}
      testID="ragdoll-arena"
      onLayout={(event) =>
        onLayout(event.nativeEvent.layout.width, event.nativeEvent.layout.height)
      }
      style={styles.arenaCanvas}
    >
      <Svg
        width="100%"
        height="100%"
        viewBox={`0 0 ${WORLD_WIDTH} ${WORLD_HEIGHT}`}
        preserveAspectRatio="none"
      >
        <Defs>
          <SvgGradient id="arenaSky" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor={colors.gameSky} />
            <Stop offset="1" stopColor={colors.card} />
          </SvgGradient>
        </Defs>
        <Rect width={WORLD_WIDTH} height={WORLD_HEIGHT} fill="url(#arenaSky)" />
        <Circle cx="310" cy="80" r="112" fill={colors.gameGlow} opacity="0.06" />
        <Circle cx="75" cy="230" r="84" fill={colors.accent} opacity="0.055" />
        {Array.from({ length: 10 }, (_, index) => (
          <Line
            key={`grid-${index}`}
            x1="27"
            y1={54 + index * 44}
            x2="363"
            y2={54 + index * 44}
            stroke={colors.gameGrid}
            strokeWidth="1"
            opacity="0.65"
          />
        ))}
        <Line x1="27" y1="28" x2="27" y2={FLOOR_Y} stroke={colors.gameGrid} strokeWidth="3" />
        <Line x1="363" y1="28" x2="363" y2={FLOOR_Y} stroke={colors.gameGrid} strokeWidth="3" />
        <SvgText x="43" y="49" fill={colors.mutedForeground} fontSize="10" letterSpacing="2">
          {modeTitle}
        </SvgText>
        {mode === 'fan' && (
          <G opacity="0.8">
            <Circle cx="76" cy="344" r="28" fill={colors.secondary} stroke={colors.primary} strokeWidth="3" />
            <Circle cx="76" cy="344" r="6" fill={colors.primary} />
            <Path
              d="M76 344 C 93 333 95 318 88 315 C 80 312 74 328 76 344 M76 344 C 83 361 99 364 102 357 C 105 349 88 342 76 344 M76 344 C 59 355 57 370 64 373 C 72 376 78 360 76 344"
              fill={colors.primary}
              opacity="0.75"
            />
            <Path d="M112 318 Q144 344 111 372 M130 309 Q169 344 128 381" fill="none" stroke={colors.primary} strokeWidth="3" strokeLinecap="round" opacity="0.55" />
          </G>
        )}
        {mode === 'bumper' &&
          BUMPERS[mode].map((bumper, index) => (
            <G key={`bumper-${index}`}>
              <Circle cx={bumper.x} cy={bumper.y} r={bumper.radius + 8} fill={colors.accent} opacity="0.12" />
              <Circle cx={bumper.x} cy={bumper.y} r={bumper.radius} fill={colors.gameHazard} stroke={colors.gameOutline} strokeWidth="5" />
              <Circle cx={bumper.x - 7} cy={bumper.y - 8} r="5" fill={colors.foreground} opacity="0.44" />
            </G>
          ))}
        {PLATFORMS[mode].map((platform, index) => (
          <G key={`platform-${index}`}>
            <Rect
              x={platform.x}
              y={platform.y}
              width={platform.width}
              height={platform.height}
              rx="7"
              fill={mode === 'bounce' ? colors.primary : colors.secondary}
              stroke={colors.gameOutline}
              strokeWidth="4"
            />
            <Rect
              x={platform.x + 10}
              y={platform.y + 4}
              width={platform.width - 20}
              height="3"
              rx="2"
              fill={mode === 'bounce' ? colors.primaryForeground : colors.accent}
              opacity="0.72"
            />
          </G>
        ))}
        <Rect x="0" y={FLOOR_Y} width={WORLD_WIDTH} height={WORLD_HEIGHT - FLOOR_Y} fill={colors.gameFloor} />
        <Rect x="0" y={FLOOR_Y} width={WORLD_WIDTH} height="5" fill={colors.primary} opacity="0.8" />
        {Array.from({ length: 13 }, (_, index) => (
          <Line
            key={`floor-mark-${index}`}
            x1={index * 34}
            y1={FLOOR_Y + 14}
            x2={index * 34 - 18}
            y2={WORLD_HEIGHT}
            stroke={colors.gameGrid}
            strokeWidth="2"
          />
        ))}
        <Ragdoll state={state} color={skinColor} outline={colors.gameOutline} />
      </Svg>
    </View>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [screen, setScreen] = useState<Screen>('home');
  const [selectedMode, setSelectedMode] = useState<ModeId>('bounce');
  const [activeMode, setActiveMode] = useState<ModeId>('bounce');
  const [save, setSave] = useState<SaveData>(DEFAULT_SAVE);
  const [saveLoaded, setSaveLoaded] = useState(false);
  const [storageIssue, setStorageIssue] = useState(false);
  const [paused, setPaused] = useState(false);
  const [frame, setFrame] = useState(0);
  const [result, setResult] = useState<{ score: number; coins: number; record: boolean } | null>(null);
  const gameRef = useRef<PhysicsState>(createPhysicsState());
  const rafRef = useRef<number | null>(null);
  const touchRef = useRef({ x: 0, y: 0 });
  const dragScaleRef = useRef({ x: 1, y: 1 });

  const pageTop = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const pageBottom = Platform.OS === 'web' ? Math.max(insets.bottom, 34) : insets.bottom;
  const selectedInfo = MODES.find((mode) => mode.id === selectedMode) ?? MODES[0];
  const modeInfo = MODES.find((mode) => mode.id === activeMode) ?? MODES[0];
  const skinColor = getSkinColor(save.selectedSkin, colors);
  const physics = gameRef.current;
  const bestScore = save.bestScores[activeMode];

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(SAVE_KEY)
      .then((raw) => {
        if (!mounted) return;
        if (raw) {
          const stored = JSON.parse(raw) as Partial<SaveData>;
          setSave({
            ...DEFAULT_SAVE,
            ...stored,
            bestScores: { ...DEFAULT_SAVE.bestScores, ...stored.bestScores },
            unlockedSkins: Array.isArray(stored.unlockedSkins)
              ? (stored.unlockedSkins as SkinId[])
              : DEFAULT_SAVE.unlockedSkins,
          });
        }
      })
      .catch(() => {
        if (mounted) setStorageIssue(true);
      })
      .finally(() => {
        if (mounted) setSaveLoaded(true);
      });
    return () => {
      mounted = false;
    };
  }, []);

  const persistSave = useCallback(async (next: SaveData) => {
    setSave(next);
    try {
      await AsyncStorage.setItem(SAVE_KEY, JSON.stringify(next));
      setStorageIssue(false);
    } catch {
      setStorageIssue(true);
    }
  }, []);

  useEffect(() => {
    if (screen !== 'game' || paused) {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
      return;
    }

    let lastTime = 0;
    let accumulator = 0;
    let paintCounter = 0;
    const loop = (time: number) => {
      if (lastTime === 0) lastTime = time;
      accumulator += Math.min(40, time - lastTime);
      lastTime = time;
      while (accumulator >= 16.67) {
        stepPhysics(gameRef.current, activeMode);
        accumulator -= 16.67;
      }
      paintCounter += 1;
      if (paintCounter % 2 === 0) setFrame((previous) => previous + 1);
      rafRef.current = requestAnimationFrame(loop);
    };

    rafRef.current = requestAnimationFrame(loop);
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    };
  }, [activeMode, paused, screen]);

  const setCanvasLayout = useCallback((width: number, height: number) => {
    dragScaleRef.current = {
      x: WORLD_WIDTH / Math.max(1, width),
      y: WORLD_HEIGHT / Math.max(1, height),
    };
  }, []);

  const responder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: () => true,
        onPanResponderGrant: (event) => {
          const x = event.nativeEvent.locationX * dragScaleRef.current.x;
          const y = event.nativeEvent.locationY * dragScaleRef.current.y;
          touchRef.current = { x, y };
          grabNearestPoint(gameRef.current, x, y);
        },
        onPanResponderMove: (_event, gesture) => {
          moveGrabbedPoint(
            gameRef.current,
            touchRef.current.x + gesture.dx * dragScaleRef.current.x,
            touchRef.current.y + gesture.dy * dragScaleRef.current.y,
          );
        },
        onPanResponderRelease: (_event, gesture) => {
          releaseGrabbedPoint(
            gameRef.current,
            gesture.vx * 12 * dragScaleRef.current.x,
            gesture.vy * 12 * dragScaleRef.current.y,
          );
        },
        onPanResponderTerminate: () => {
          releaseGrabbedPoint(gameRef.current, 0, 0);
        },
      }),
    [],
  );

  const startGame = useCallback(
    (mode: ModeId) => {
      gameRef.current = createPhysicsState();
      setActiveMode(mode);
      setPaused(false);
      setScreen('game');
      setResult(null);
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    },
    [],
  );

  const kick = useCallback(() => {
    launchRagdoll(gameRef.current, 1 + Math.min(0.45, gameRef.current.elapsed / 28));
    gameRef.current.score += 6;
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }, []);

  const finishRun = useCallback(async () => {
    const finalScore =
      gameRef.current.score +
      Math.floor(gameRef.current.elapsed * 1.4) +
      gameRef.current.impacts * 3;
    const earned = Math.max(4, Math.floor(finalScore / 22));
    const nextBest = Math.max(save.bestScores[activeMode], finalScore);
    const nextSave: SaveData = {
      ...save,
      coins: save.coins + earned,
      bestScores: { ...save.bestScores, [activeMode]: nextBest },
    };
    setResult({
      score: finalScore,
      coins: earned,
      record: finalScore > save.bestScores[activeMode],
    });
    await persistSave(nextSave);
    setPaused(false);
    setScreen('results');
    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  }, [activeMode, persistSave, save]);

  const handleSkin = useCallback(
    async (skin: SkinInfo) => {
      if (save.unlockedSkins.includes(skin.id)) {
        await persistSave({ ...save, selectedSkin: skin.id });
        void Haptics.selectionAsync();
        return;
      }
      if (save.coins < skin.cost) return;
      await persistSave({
        ...save,
        coins: save.coins - skin.cost,
        unlockedSkins: [...save.unlockedSkins, skin.id],
        selectedSkin: skin.id,
      });
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    },
    [persistSave, save],
  );

  const stylesWithInsets = [
    styles.root,
    { backgroundColor: colors.background, paddingTop: pageTop, paddingBottom: pageBottom },
  ];

  if (!saveLoaded) {
    return (
      <View style={stylesWithInsets}>
        <StatusBar barStyle="light-content" />
        <View style={styles.loading}>
          <View style={[styles.loadingOrb, { backgroundColor: colors.primary }]} />
          <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>SETTING UP THE TEST BAY</Text>
        </View>
      </View>
    );
  }

  if (screen === 'game') {
    return (
      <View style={stylesWithInsets}>
        <StatusBar barStyle="light-content" />
        <View style={styles.gameHeader}>
          <IconButton
            icon="arrow-left"
            label="Leave test"
            testID="leave-game"
            color={colors.foreground}
            onPress={() => {
              setPaused(false);
              setScreen('home');
            }}
          />
          <View style={styles.gameHeaderCenter}>
            <Text style={[styles.eyebrow, { color: colors.primary }]}>{modeInfo.title}</Text>
            <Text style={[styles.gameHeaderTitle, { color: colors.foreground }]}>FREE PLAY</Text>
          </View>
          <IconButton
            icon={paused ? 'play' : 'pause'}
            label={paused ? 'Resume game' : 'Pause game'}
            testID="pause-game"
            color={colors.foreground}
            onPress={() => setPaused((value) => !value)}
          />
        </View>
        <View style={styles.scoreStrip}>
          <View>
            <Text style={[styles.scoreLabel, { color: colors.mutedForeground }]}>RUN SCORE</Text>
            <Text style={[styles.scoreValue, { color: colors.foreground }]}>{formatScore(physics.score + Math.floor(physics.elapsed * 1.4))}</Text>
          </View>
          <View style={[styles.scoreDivider, { backgroundColor: colors.border }]} />
          <View>
            <Text style={[styles.scoreLabel, { color: colors.mutedForeground }]}>BEST</Text>
            <Text style={[styles.scoreSmallValue, { color: colors.primary }]}>{formatScore(bestScore)}</Text>
          </View>
          <View style={[styles.scoreDivider, { backgroundColor: colors.border }]} />
          <View>
            <Text style={[styles.scoreLabel, { color: colors.mutedForeground }]}>IMPACTS</Text>
            <Text style={[styles.scoreSmallValue, { color: colors.accent }]}>{physics.impacts}</Text>
          </View>
        </View>
        <ArenaCanvas
          state={physics}
          mode={activeMode}
          skinColor={skinColor}
          colors={colors}
          onLayout={setCanvasLayout}
          responder={responder.panHandlers}
        />
        <View style={styles.gameHintRow}>
          <Feather name="move" size={14} color={colors.primary} />
          <Text style={[styles.gameHint, { color: colors.mutedForeground }]}>DRAG ANY LIMB · RELEASE TO THROW</Text>
        </View>
        <View style={styles.gameControls}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Reset ragdoll"
            testID="reset-ragdoll"
            onPress={() => {
              gameRef.current = createPhysicsState();
              setFrame((value) => value + 1);
            }}
            style={({ pressed }) => [
              styles.secondaryButton,
              { borderColor: colors.border, backgroundColor: colors.card },
              pressed && styles.pressed,
            ]}
          >
            <Feather name="rotate-ccw" size={17} color={colors.foreground} />
            <Text style={[styles.secondaryButtonText, { color: colors.foreground }]}>RESET</Text>
          </Pressable>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Give ragdoll a boost"
            testID="kick-ragdoll"
            onPress={kick}
            style={({ pressed }) => [
              styles.kickButton,
              { backgroundColor: colors.accent },
              pressed && styles.pressed,
            ]}
          >
            <Feather name="zap" size={19} color={colors.accentForeground} />
            <Text style={[styles.kickButtonText, { color: colors.accentForeground }]}>BOOST</Text>
          </Pressable>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="End this run and save score"
            testID="bank-score"
            onPress={() => void finishRun()}
            style={({ pressed }) => [
              styles.secondaryButton,
              { borderColor: colors.border, backgroundColor: colors.card },
              pressed && styles.pressed,
            ]}
          >
            <Feather name="check" size={17} color={colors.primary} />
            <Text style={[styles.secondaryButtonText, { color: colors.foreground }]}>BANK</Text>
          </Pressable>
        </View>
        {paused && (
          <View style={[styles.pauseOverlay, { backgroundColor: colors.gameOutline }]}>
            <View style={[styles.pauseCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Feather name="pause-circle" size={40} color={colors.primary} />
              <Text style={[styles.pauseTitle, { color: colors.foreground }]}>TEST PAUSED</Text>
              <Text style={[styles.pauseBody, { color: colors.mutedForeground }]}>The ragdoll is waiting right where you left it.</Text>
              <PrimaryButton
                title="RESUME"
                icon="play"
                testID="resume-game"
                colors={colors}
                onPress={() => setPaused(false)}
              />
            </View>
          </View>
        )}
        <Text style={styles.renderTick} accessibilityElementsHidden>{frame}</Text>
      </View>
    );
  }

  if (screen === 'results' && result) {
    return (
      <View style={stylesWithInsets}>
        <StatusBar barStyle="light-content" />
        <View style={styles.resultTop}>
          <IconButton
            icon="x"
            label="Return to menu"
            testID="results-home"
            color={colors.foreground}
            onPress={() => setScreen('home')}
          />
          <Text style={[styles.eyebrow, { color: colors.primary }]}>RUN SAVED LOCALLY</Text>
          <View style={styles.iconSpacer} />
        </View>
        <View style={styles.resultContent}>
          <View style={[styles.resultIcon, { backgroundColor: colors.secondary }]}>
            <Feather name={result.record ? 'award' : 'activity'} size={34} color={colors.primary} />
          </View>
          <Text style={[styles.resultKicker, { color: colors.accent }]}>{result.record ? 'NEW PERSONAL BEST' : 'TEST COMPLETE'}</Text>
          <Text style={[styles.resultScore, { color: colors.foreground }]}>{formatScore(result.score)}</Text>
          <Text style={[styles.resultLabel, { color: colors.mutedForeground }]}>POINTS EARNED</Text>
          <View style={[styles.rewardPill, { backgroundColor: colors.secondary }]}>
            <Feather name="circle" size={15} color={colors.accent} />
            <Text style={[styles.rewardText, { color: colors.foreground }]}>+{result.coins} lab tokens</Text>
          </View>
          <Text style={[styles.resultCopy, { color: colors.mutedForeground }]}>
            Your score and tokens are saved on this device. No connection needed.
          </Text>
        </View>
        <View style={styles.resultButtons}>
          <PrimaryButton
            title="RUN IT BACK"
            icon="rotate-ccw"
            testID="replay-run"
            colors={colors}
            onPress={() => startGame(activeMode)}
          />
          <Pressable
            accessibilityRole="button"
            testID="result-locker"
            onPress={() => setScreen('locker')}
            style={({ pressed }) => [styles.textButton, pressed && styles.pressed]}
          >
            <Feather name="shopping-bag" size={17} color={colors.primary} />
            <Text style={[styles.textButtonLabel, { color: colors.primary }]}>VISIT THE LOCKER</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  if (screen === 'locker') {
    return (
      <View style={stylesWithInsets}>
        <StatusBar barStyle="light-content" />
        <View style={styles.gameHeader}>
          <IconButton
            icon="arrow-left"
            label="Back to menu"
            testID="locker-back"
            color={colors.foreground}
            onPress={() => setScreen('home')}
          />
          <View style={styles.gameHeaderCenter}>
            <Text style={[styles.eyebrow, { color: colors.primary }]}>OFFLINE SHOP</Text>
            <Text style={[styles.gameHeaderTitle, { color: colors.foreground }]}>THE LOCKER</Text>
          </View>
          <View style={styles.coinPill}>
            <Feather name="circle" size={13} color={colors.accent} />
            <Text style={[styles.coinText, { color: colors.foreground }]}>{save.coins}</Text>
          </View>
        </View>
        <ScrollView contentContainerStyle={styles.lockerContent} showsVerticalScrollIndicator={false}>
          <Text style={[styles.sectionLead, { color: colors.mutedForeground }]}>
            Fresh paint for your test dummy. Unlocks stay on this device.
          </Text>
          {SKINS.map((skin) => {
            const owned = save.unlockedSkins.includes(skin.id);
            const selected = save.selectedSkin === skin.id;
            const canBuy = save.coins >= skin.cost;
            return (
              <View key={skin.id} style={[styles.skinCard, { backgroundColor: colors.card, borderColor: selected ? colors.primary : colors.border }]}>
                <View style={[styles.skinSwatch, { backgroundColor: colors[skin.colorToken] as string }]}>
                  <View style={[styles.skinDot, { backgroundColor: colors.gameOutline }]} />
                </View>
                <View style={styles.skinInfo}>
                  <Text style={[styles.skinName, { color: colors.foreground }]}>{skin.name}</Text>
                  <Text style={[styles.skinState, { color: colors.mutedForeground }]}>
                    {selected ? 'IN USE' : owned ? 'UNLOCKED' : `${skin.cost} TOKENS`}
                  </Text>
                </View>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={selected ? `${skin.name} selected` : owned ? `Select ${skin.name}` : `Unlock ${skin.name}`}
                  testID={`skin-${skin.id}`}
                  disabled={selected || (!owned && !canBuy)}
                  onPress={() => void handleSkin(skin)}
                  style={({ pressed }) => [
                    styles.skinAction,
                    { backgroundColor: selected ? colors.secondary : colors.primary, opacity: !owned && !canBuy ? 0.45 : 1 },
                    pressed && styles.pressed,
                  ]}
                >
                  <Feather
                    name={selected ? 'check' : owned ? 'check' : 'plus'}
                    size={17}
                    color={selected ? colors.primary : colors.primaryForeground}
                  />
                </Pressable>
              </View>
            );
          })}
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={stylesWithInsets}>
      <StatusBar barStyle="light-content" />
      <ScrollView
        contentContainerStyle={styles.homeContent}
        showsVerticalScrollIndicator={false}
        bounces={false}
      >
        <View style={styles.homeHeader}>
          <View style={styles.brandLockup}>
            <View style={[styles.brandMark, { backgroundColor: colors.primary }]}>
              <Feather name="activity" size={18} color={colors.primaryForeground} />
            </View>
            <View>
              <Text style={[styles.brandName, { color: colors.foreground }]}>BOUNCE LAB</Text>
              <Text style={[styles.brandCaption, { color: colors.mutedForeground }]}>OFFLINE PHYSICS CLUB</Text>
            </View>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Open the locker"
            testID="open-locker"
            onPress={() => setScreen('locker')}
            style={({ pressed }) => [
              styles.coinPill,
              { backgroundColor: colors.card, borderColor: colors.border },
              pressed && styles.pressed,
            ]}
          >
            <Feather name="circle" size={14} color={colors.accent} />
            <Text style={[styles.coinText, { color: colors.foreground }]}>{save.coins}</Text>
            <Feather name="arrow-up-right" size={13} color={colors.mutedForeground} />
          </Pressable>
        </View>

        <View style={styles.hero}>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>PHYSICS, WITHOUT THE RULEBOOK</Text>
          <Text style={[styles.heroTitle, { color: colors.foreground }]}>
            MAKE GRAVITY{'\n'}LOOK FUN.
          </Text>
          <Text style={[styles.heroCopy, { color: colors.mutedForeground }]}>
            Toss, tumble, and try something ridiculous. Your test bay works offline.
          </Text>
        </View>

        <View style={[styles.previewCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <LinearGradient
            colors={[colors.secondary, colors.card, colors.background]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.previewGlow}
          />
          <View style={styles.previewMeta}>
            <View style={[styles.statusDot, { backgroundColor: colors.primary }]} />
            <Text style={[styles.previewMetaText, { color: colors.mutedForeground }]}>TEST BAY 01 · READY</Text>
          </View>
          <View style={styles.previewArt}>
            <Svg width="180" height="150" viewBox="0 0 180 150">
              <Circle cx="95" cy="75" r="65" fill={colors.primary} opacity="0.09" />
              <Line x1="92" y1="66" x2="102" y2="91" stroke={colors.gameOutline} strokeWidth="20" strokeLinecap="round" />
              <Line x1="92" y1="66" x2="102" y2="91" stroke={skinColor} strokeWidth="13" strokeLinecap="round" />
              <Line x1="92" y1="67" x2="68" y2="91" stroke={colors.gameOutline} strokeWidth="13" strokeLinecap="round" />
              <Line x1="92" y1="67" x2="68" y2="91" stroke={skinColor} strokeWidth="8" strokeLinecap="round" />
              <Line x1="92" y1="67" x2="120" y2="73" stroke={colors.gameOutline} strokeWidth="13" strokeLinecap="round" />
              <Line x1="92" y1="67" x2="120" y2="73" stroke={skinColor} strokeWidth="8" strokeLinecap="round" />
              <Line x1="102" y1="91" x2="84" y2="121" stroke={colors.gameOutline} strokeWidth="14" strokeLinecap="round" />
              <Line x1="102" y1="91" x2="84" y2="121" stroke={skinColor} strokeWidth="9" strokeLinecap="round" />
              <Line x1="102" y1="91" x2="126" y2="113" stroke={colors.gameOutline} strokeWidth="14" strokeLinecap="round" />
              <Line x1="102" y1="91" x2="126" y2="113" stroke={skinColor} strokeWidth="9" strokeLinecap="round" />
              <Circle cx="88" cy="45" r="17" fill={skinColor} stroke={colors.gameOutline} strokeWidth="4" />
              <Circle cx="82" cy="43" r="2" fill={colors.gameOutline} />
              <Circle cx="94" cy="43" r="2" fill={colors.gameOutline} />
              <Path d="M83 50 Q88 54 93 50" fill="none" stroke={colors.gameOutline} strokeWidth="2" strokeLinecap="round" />
              <Circle cx="38" cy="44" r="4" fill={colors.accent} />
              <Circle cx="145" cy="46" r="3" fill={colors.primary} />
              <Circle cx="149" cy="103" r="5" fill={colors.accent} opacity="0.8" />
            </Svg>
            <View style={[styles.previewBadge, { backgroundColor: colors.background, borderColor: colors.border }]}>
              <Feather name="wind" size={14} color={colors.primary} />
              <Text style={[styles.previewBadgeText, { color: colors.foreground }]}>NO RULES. JUST PHYSICS.</Text>
            </View>
          </View>
          <View style={styles.previewBottom}>
            <View>
              <Text style={[styles.previewMode, { color: colors.foreground }]}>{selectedInfo.title}</Text>
              <Text style={[styles.previewDesc, { color: colors.mutedForeground }]}>{selectedInfo.detail}</Text>
            </View>
            <Feather name="arrow-up-right" size={20} color={colors.primary} />
          </View>
        </View>

        <View style={styles.sectionHeading}>
          <View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>CHOOSE YOUR TEST</Text>
            <Text style={[styles.sectionNote, { color: colors.mutedForeground }]}>Three ways to bend the rules of gravity.</Text>
          </View>
          <Text style={[styles.sectionCount, { color: colors.mutedForeground }]}>01 / 03</Text>
        </View>
        <View style={styles.modeList}>
          {MODES.map((mode) => (
            <ModeCard
              key={mode.id}
              mode={mode}
              selected={selectedMode === mode.id}
              best={save.bestScores[mode.id]}
              colors={colors}
              onPress={() => {
                setSelectedMode(mode.id);
                void Haptics.selectionAsync();
              }}
            />
          ))}
        </View>

        {storageIssue && (
          <View style={[styles.storageNotice, { borderColor: colors.accent }]}>
            <Feather name="alert-circle" size={15} color={colors.accent} />
            <Text style={[styles.storageNoticeText, { color: colors.mutedForeground }]}>
              Local storage is unavailable. Progress may not survive closing the app.
            </Text>
          </View>
        )}

        <View style={styles.playArea}>
          <PrimaryButton
            title="ENTER THE TEST BAY"
            icon="arrow-up-right"
            testID="start-game"
            colors={colors}
            onPress={() => startGame(selectedMode)}
          />
          <View style={styles.playFootnote}>
            <Feather name="smartphone" size={13} color={colors.mutedForeground} />
            <Text style={[styles.playFootnoteText, { color: colors.mutedForeground }]}>
              OFFLINE PLAY · LOCAL SCORES · NO ACCOUNT
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    paddingHorizontal: 20,
  },
  loading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 17,
  },
  loadingOrb: {
    width: 20,
    height: 20,
    borderRadius: 10,
  },
  loadingText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 11,
    letterSpacing: 2,
  },
  homeContent: {
    paddingBottom: 24,
    gap: 22,
  },
  homeHeader: {
    minHeight: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  brandLockup: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 11,
  },
  brandMark: {
    width: 39,
    height: 39,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  brandName: {
    fontFamily: 'Inter_700Bold',
    fontSize: 14,
    letterSpacing: 1.2,
  },
  brandCaption: {
    marginTop: 3,
    fontFamily: 'Inter_500Medium',
    fontSize: 8,
    letterSpacing: 1.1,
  },
  coinPill: {
    minHeight: 38,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    paddingHorizontal: 12,
    borderRadius: 20,
    borderWidth: 1,
  },
  coinText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 12,
  },
  hero: {
    gap: 10,
    paddingTop: 4,
  },
  eyebrow: {
    fontFamily: 'Inter_700Bold',
    fontSize: 10,
    letterSpacing: 1.8,
  },
  heroTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 41,
    lineHeight: 44,
    letterSpacing: -1.6,
  },
  heroCopy: {
    maxWidth: 310,
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    lineHeight: 21,
  },
  previewCard: {
    minHeight: 232,
    borderRadius: 23,
    borderWidth: 1,
    overflow: 'hidden',
    paddingHorizontal: 16,
    paddingTop: 14,
    paddingBottom: 15,
  },
  previewGlow: {
    ...StyleSheet.absoluteFill,
    opacity: 0.55,
  },
  previewMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  previewMetaText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 9,
    letterSpacing: 1.2,
  },
  previewArt: {
    height: 142,
    alignItems: 'center',
    justifyContent: 'center',
  },
  previewBadge: {
    position: 'absolute',
    right: 0,
    bottom: 9,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    borderWidth: 1,
    borderRadius: 18,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  previewBadgeText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 8,
    letterSpacing: 0.8,
  },
  previewBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  previewMode: {
    fontFamily: 'Inter_700Bold',
    fontSize: 14,
    letterSpacing: 0.9,
  },
  previewDesc: {
    marginTop: 4,
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
  },
  sectionHeading: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    marginTop: 2,
  },
  sectionTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 13,
    letterSpacing: 1.2,
  },
  sectionNote: {
    marginTop: 5,
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
  },
  sectionCount: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 9,
    letterSpacing: 1,
    marginBottom: 2,
  },
  modeList: {
    gap: 9,
    marginTop: -12,
  },
  modeCard: {
    minHeight: 70,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderRadius: 17,
    paddingHorizontal: 12,
    paddingVertical: 11,
  },
  modeIcon: {
    width: 39,
    height: 39,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modeText: {
    flex: 1,
    gap: 4,
  },
  modeTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 11,
    letterSpacing: 0.75,
  },
  modeSub: {
    fontFamily: 'Inter_400Regular',
    fontSize: 10,
  },
  modeBest: {
    fontFamily: 'Inter_700Bold',
    fontSize: 9,
    letterSpacing: 0.4,
  },
  playArea: {
    gap: 12,
    paddingTop: 1,
  },
  primaryButton: {
    minHeight: 55,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    borderRadius: 16,
    paddingHorizontal: 18,
  },
  primaryButtonText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 12,
    letterSpacing: 1.15,
  },
  playFootnote: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
  },
  playFootnoteText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 8,
    letterSpacing: 1,
  },
  iconButton: {
    width: 43,
    height: 43,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 22,
  },
  pressed: {
    opacity: 0.72,
    transform: [{ scale: 0.97 }],
  },
  gameHeader: {
    height: 56,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  gameHeaderCenter: {
    alignItems: 'center',
    gap: 3,
  },
  gameHeaderTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 14,
    letterSpacing: 1,
  },
  scoreStrip: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    minHeight: 67,
    borderRadius: 16,
    marginTop: 4,
    marginBottom: 12,
  },
  scoreLabel: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 8,
    letterSpacing: 1.1,
  },
  scoreValue: {
    marginTop: 3,
    fontFamily: 'Inter_700Bold',
    fontSize: 22,
  },
  scoreSmallValue: {
    marginTop: 5,
    fontFamily: 'Inter_700Bold',
    fontSize: 15,
  },
  scoreDivider: {
    height: 31,
    width: 1,
  },
  arenaCanvas: {
    flex: 1,
    minHeight: 280,
    maxHeight: 500,
    borderRadius: 21,
    overflow: 'hidden',
  },
  gameHintRow: {
    minHeight: 30,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  gameHint: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 9,
    letterSpacing: 0.8,
  },
  gameControls: {
    flexDirection: 'row',
    gap: 9,
    paddingBottom: 5,
  },
  secondaryButton: {
    minHeight: 52,
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    borderWidth: 1,
    borderRadius: 15,
  },
  secondaryButtonText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 9,
    letterSpacing: 0.8,
  },
  kickButton: {
    minHeight: 52,
    flex: 1.15,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    borderRadius: 15,
  },
  kickButtonText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 10,
    letterSpacing: 1,
  },
  pauseOverlay: {
    ...StyleSheet.absoluteFill,
    zIndex: 5,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    opacity: 0.94,
  },
  pauseCard: {
    width: '100%',
    maxWidth: 360,
    alignItems: 'center',
    gap: 13,
    borderWidth: 1,
    borderRadius: 24,
    padding: 25,
  },
  pauseTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 20,
    letterSpacing: 1,
  },
  pauseBody: {
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
    fontSize: 13,
    lineHeight: 19,
    marginBottom: 4,
  },
  renderTick: {
    position: 'absolute',
    width: 1,
    height: 1,
    opacity: 0,
  },
  resultTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 54,
  },
  iconSpacer: {
    width: 43,
  },
  resultContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  resultIcon: {
    width: 76,
    height: 76,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 23,
  },
  resultKicker: {
    fontFamily: 'Inter_700Bold',
    fontSize: 10,
    letterSpacing: 1.8,
  },
  resultScore: {
    marginTop: 8,
    fontFamily: 'Inter_700Bold',
    fontSize: 62,
    letterSpacing: -2,
  },
  resultLabel: {
    marginTop: -2,
    fontFamily: 'Inter_600SemiBold',
    fontSize: 10,
    letterSpacing: 1.8,
  },
  rewardPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderRadius: 20,
    paddingHorizontal: 15,
    paddingVertical: 10,
    marginTop: 25,
  },
  rewardText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 12,
  },
  resultCopy: {
    maxWidth: 270,
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    lineHeight: 19,
    textAlign: 'center',
    marginTop: 20,
  },
  resultButtons: {
    gap: 16,
    paddingBottom: 18,
  },
  textButton: {
    minHeight: 42,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 9,
  },
  textButtonLabel: {
    fontFamily: 'Inter_700Bold',
    fontSize: 10,
    letterSpacing: 1,
  },
  lockerContent: {
    paddingTop: 16,
    paddingBottom: 28,
    gap: 11,
  },
  sectionLead: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    lineHeight: 20,
    marginBottom: 4,
  },
  skinCard: {
    minHeight: 76,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 13,
    borderWidth: 1,
    borderRadius: 18,
    padding: 12,
  },
  skinSwatch: {
    width: 47,
    height: 47,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  skinDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  skinInfo: {
    flex: 1,
    gap: 5,
  },
  skinName: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 13,
  },
  skinState: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 9,
    letterSpacing: 0.9,
  },
  skinAction: {
    width: 39,
    height: 39,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  storageNotice: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 9,
    borderWidth: 1,
    borderRadius: 13,
    padding: 12,
  },
  storageNoticeText: {
    flex: 1,
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
    lineHeight: 16,
  },
});
