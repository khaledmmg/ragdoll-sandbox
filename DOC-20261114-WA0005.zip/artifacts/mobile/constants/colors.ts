/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const darkTokens = {
  text: '#eff8f5',
  tint: '#59e4c6',
  background: '#08171d',
  foreground: '#eff8f5',
  card: '#10262e',
  cardForeground: '#eff8f5',
  primary: '#59e4c6',
  primaryForeground: '#06201b',
  secondary: '#19343d',
  secondaryForeground: '#d0e1dd',
  muted: '#142a32',
  mutedForeground: '#8da7a8',
  accent: '#ff9b61',
  accentForeground: '#291409',
  destructive: '#fa6476',
  destructiveForeground: '#ffffff',
  border: '#29414a',
  input: '#203a43',
  gameSky: '#0b2029',
  gameGrid: '#18343d',
  gameFloor: '#15343b',
  gameOutline: '#07151a',
  gameHazard: '#ff9b61',
  gameGlow: '#59e4c6',
  skinCitrus: '#ffc95f',
  skinSky: '#67b9ff',
  skinRose: '#ff7d91',
};

const colors = {
  light: darkTokens,
  dark: darkTokens,
  radius: 18,
};

export default colors;
