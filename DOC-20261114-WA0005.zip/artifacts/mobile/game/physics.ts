export type ModeId = 'bounce' | 'fan' | 'bumper';

export interface PhysicsPoint {
  x: number;
  y: number;
  previousX: number;
  previousY: number;
  radius: number;
}

export interface PhysicsState {
  points: PhysicsPoint[];
  score: number;
  elapsed: number;
  impacts: number;
  combo: number;
  impactCooldown: number;
  comboWindow: number;
  airTicks: number;
  grabbedIndex: number | null;
}

export interface Platform {
  x: number;
  y: number;
  width: number;
  height: number;
  bounce: number;
}

export interface Bumper {
  x: number;
  y: number;
  radius: number;
}

export interface Joint {
  a: number;
  b: number;
  length: number;
  width: number;
}

export const WORLD_WIDTH = 390;
export const WORLD_HEIGHT = 520;
export const FLOOR_Y = 486;

export const JOINTS: Joint[] = [
  { a: 0, b: 1, length: 29, width: 19 },
  { a: 1, b: 2, length: 35, width: 23 },
  { a: 2, b: 3, length: 46, width: 25 },
  { a: 1, b: 4, length: 34, width: 17 },
  { a: 4, b: 5, length: 31, width: 15 },
  { a: 1, b: 6, length: 34, width: 17 },
  { a: 6, b: 7, length: 31, width: 15 },
  { a: 3, b: 8, length: 40, width: 20 },
  { a: 8, b: 9, length: 36, width: 17 },
  { a: 3, b: 10, length: 40, width: 20 },
  { a: 10, b: 11, length: 36, width: 17 },
];

export const PLATFORMS: Record<ModeId, Platform[]> = {
  bounce: [
    { x: 52, y: 416, width: 108, height: 17, bounce: 0.86 },
    { x: 231, y: 350, width: 93, height: 17, bounce: 0.78 },
  ],
  fan: [
    { x: 48, y: 440, width: 94, height: 16, bounce: 0.5 },
    { x: 247, y: 386, width: 90, height: 16, bounce: 0.52 },
  ],
  bumper: [
    { x: 35, y: 429, width: 86, height: 16, bounce: 0.56 },
    { x: 267, y: 324, width: 90, height: 16, bounce: 0.62 },
  ],
};

export const BUMPERS: Record<ModeId, Bumper[]> = {
  bounce: [{ x: 195, y: 444, radius: 25 }],
  fan: [],
  bumper: [
    { x: 151, y: 384, radius: 26 },
    { x: 253, y: 271, radius: 23 },
    { x: 95, y: 299, radius: 20 },
  ],
};

export function createPhysicsState(): PhysicsState {
  const positions = [
    [195, 192, 19],
    [195, 223, 11],
    [195, 260, 12],
    [195, 306, 12],
    [162, 244, 9],
    [143, 270, 8],
    [228, 244, 9],
    [247, 270, 8],
    [171, 344, 10],
    [162, 378, 9],
    [219, 344, 10],
    [228, 378, 9],
  ];

  return {
    points: positions.map(([x, y, radius]) => ({
      x,
      y,
      previousX: x,
      previousY: y,
      radius,
    })),
    score: 0,
    elapsed: 0,
    impacts: 0,
    combo: 0,
    impactCooldown: 0,
    comboWindow: 0,
    airTicks: 0,
    grabbedIndex: null,
  };
}

export function launchRagdoll(state: PhysicsState, power = 1): void {
  state.points.forEach((point, index) => {
    const sway = Math.sin(index * 1.7) * 1.25;
    const vx = 2.6 * power + sway;
    const vy = -5.2 * power + Math.cos(index * 0.9) * 1.5;
    point.previousX = point.x - vx;
    point.previousY = point.y - vy;
  });
}

function registerImpact(state: PhysicsState, impactSpeed: number): void {
  if (impactSpeed < 4.8 || state.impactCooldown > 0) return;
  state.impactCooldown = 10;
  state.combo = state.comboWindow > 0 ? state.combo + 1 : 1;
  state.comboWindow = 42;
  state.impacts += 1;
  state.score += Math.min(24, Math.round(impactSpeed * 1.15)) + Math.min(12, state.combo * 2);
}

function constrain(state: PhysicsState): void {
  for (let iteration = 0; iteration < 6; iteration += 1) {
    JOINTS.forEach((joint) => {
      const a = state.points[joint.a];
      const b = state.points[joint.b];
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const distance = Math.max(0.001, Math.sqrt(dx * dx + dy * dy));
      const error = (distance - joint.length) / distance;
      const aWeight = state.grabbedIndex === joint.a ? 0 : 1;
      const bWeight = state.grabbedIndex === joint.b ? 0 : 1;
      const totalWeight = aWeight + bWeight;
      if (totalWeight === 0) return;
      a.x += dx * error * (aWeight / totalWeight);
      a.y += dy * error * (aWeight / totalWeight);
      b.x -= dx * error * (bWeight / totalWeight);
      b.y -= dy * error * (bWeight / totalWeight);
    });
  }
}

function reflectPoint(
  point: PhysicsPoint,
  normalX: number,
  normalY: number,
  bounce: number,
): number {
  const vx = point.x - point.previousX;
  const vy = point.y - point.previousY;
  const normalSpeed = vx * normalX + vy * normalY;
  const nextVx = vx - (1 + bounce) * normalSpeed * normalX;
  const nextVy = vy - (1 + bounce) * normalSpeed * normalY;
  point.previousX = point.x - nextVx * 0.84;
  point.previousY = point.y - nextVy * 0.84;
  return Math.abs(normalSpeed);
}

export function stepPhysics(state: PhysicsState, mode: ModeId): void {
  state.elapsed += 1 / 60;
  if (state.impactCooldown > 0) state.impactCooldown -= 1;
  if (state.comboWindow > 0) state.comboWindow -= 1;
  else state.combo = 0;

  state.points.forEach((point, index) => {
    if (state.grabbedIndex === index) return;
    let vx = (point.x - point.previousX) * 0.992;
    let vy = (point.y - point.previousY) * 0.992;

    if (mode === 'fan' && point.y > 220 && point.y < 462 && point.x > 100) {
      const gust = Math.sin(state.elapsed * 2.4) * 0.12;
      vx += 0.105 + gust;
      vy -= 0.075 + gust * 0.55;
    }

    point.previousX = point.x;
    point.previousY = point.y;
    point.x += vx;
    point.y += vy + 0.19;
  });

  constrain(state);
  let touchingGround = false;

  state.points.forEach((point) => {
    if (state.grabbedIndex !== null && state.points[state.grabbedIndex] === point) return;
    let supported = false;

    for (const platform of PLATFORMS[mode]) {
      const overlapsX =
        point.x + point.radius > platform.x &&
        point.x - point.radius < platform.x + platform.width;
      const crossedTop =
        point.y + point.radius > platform.y &&
        point.previousY + point.radius <= platform.y + 9;
      if (overlapsX && crossedTop) {
        const speed = Math.max(0, point.y - point.previousY);
        point.y = platform.y - point.radius;
        const vx = point.x - point.previousX;
        point.previousX = point.x - vx * 0.92;
        point.previousY = point.y + speed * platform.bounce;
        registerImpact(state, speed);
        supported = true;
      }
    }

    for (const bumper of BUMPERS[mode]) {
      const dx = point.x - bumper.x;
      const dy = point.y - bumper.y;
      const distance = Math.max(0.001, Math.sqrt(dx * dx + dy * dy));
      const minimum = point.radius + bumper.radius;
      if (distance < minimum) {
        const nx = dx / distance;
        const ny = dy / distance;
        point.x = bumper.x + nx * minimum;
        point.y = bumper.y + ny * minimum;
        registerImpact(state, reflectPoint(point, nx, ny, 0.82));
        supported = true;
      }
    }

    if (point.x - point.radius < 27) {
      point.x = 27 + point.radius;
      const vx = point.x - point.previousX;
      point.previousX = point.x + vx * 0.55;
    } else if (point.x + point.radius > WORLD_WIDTH - 27) {
      point.x = WORLD_WIDTH - 27 - point.radius;
      const vx = point.x - point.previousX;
      point.previousX = point.x + vx * 0.55;
    }

    if (point.y + point.radius > FLOOR_Y) {
      const speed = Math.max(0, point.y - point.previousY);
      point.y = FLOOR_Y - point.radius;
      const vx = point.x - point.previousX;
      point.previousX = point.x - vx * 0.88;
      point.previousY = point.y + speed * 0.72;
      registerImpact(state, speed);
      supported = true;
    }

    if (supported && point.y + point.radius >= FLOOR_Y - 4) touchingGround = true;
  });

  constrain(state);

  if (touchingGround) {
    if (state.airTicks > 24) {
      state.score += Math.min(42, Math.floor(state.airTicks / 3));
    }
    state.airTicks = 0;
  } else {
    state.airTicks += 1;
  }
}

export function grabNearestPoint(state: PhysicsState, x: number, y: number): number | null {
  let bestIndex: number | null = null;
  let bestDistance = 58;
  state.points.forEach((point, index) => {
    const dx = point.x - x;
    const dy = point.y - y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    if (distance < bestDistance) {
      bestDistance = distance;
      bestIndex = index;
    }
  });
  state.grabbedIndex = bestIndex;
  return bestIndex;
}

export function moveGrabbedPoint(state: PhysicsState, x: number, y: number): void {
  if (state.grabbedIndex === null) return;
  const point = state.points[state.grabbedIndex];
  point.x = Math.max(29, Math.min(WORLD_WIDTH - 29, x));
  point.y = Math.max(48, Math.min(FLOOR_Y - 4, y));
  point.previousX = point.x;
  point.previousY = point.y;
}

export function releaseGrabbedPoint(state: PhysicsState, velocityX: number, velocityY: number): void {
  if (state.grabbedIndex === null) return;
  const point = state.points[state.grabbedIndex];
  point.previousX = point.x - Math.max(-8, Math.min(8, velocityX));
  point.previousY = point.y - Math.max(-8, Math.min(8, velocityY));
  state.grabbedIndex = null;
}
